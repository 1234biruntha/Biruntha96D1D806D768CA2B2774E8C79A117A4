year =int(input("enter the year:"))
if (year % 4 == 0):
  print(" the given yrar is leaf year")
else:
  print(" the give yesr is not leaf year")
  
          