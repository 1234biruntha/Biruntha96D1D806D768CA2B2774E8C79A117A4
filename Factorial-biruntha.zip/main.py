n= int(input (" enter the number:"))
fact =1
if n < 0:
  prinf(" factorial does not exist neg")
elif n==0:
  print(" the  factorial 0 is 1")
else:
  for i in range(1,n+1):
    fact=fact *i
    print("the factorial of",n,"is",fact)
    
  
  